<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php 
//o operador de atribui��o � o igual =

$nome = "Eduardo"; //atribuo a variavel nome o valor Eduardo
echo $nome;
print "<hr>";
$nome = $nome." Pretel";
echo $nome;
print "<hr>";
echo $nome .=" Filho";
print "<hr>";

########################################
$total = 5;
echo $total;//5
$total = $total + 10;//15
print "<hr>";
echo $total;
print "<hr>";
echo $total += 10;//25


/*
=
+=
-=
*=
/=
%=
.=
*/


 ?>
</body>
</html>