<?php
// a classe descreve os objetos
// os objetos sao variaveis descritas pelas classes
class Pessoas{
	public $nome;
	public $idade;
	public $sexo;
	public $nacionalidade;
}

$edu = new Pessoas;
$edu->nome = "Eduardo";
$edu->idade = 57;
echo $edu->idade;

var_dump($edu);
##########################################################
echo "<hr>";

$otavio = new Pessoas;
$otavio->nome = "Ot�vio";
$otavio->idade = 19;
echo $otavio->idade;

var_dump($otavio);
##########################################################
echo "<hr>";

echo gettype($otavio)."<br>";//object
echo is_object($otavio);//1