<?php 

function teste(){
	echo "Ola, funcao teste<br>";
}


function quadrado(){
	$numero = 5;
	$total = $numero * $numero;
	echo $total;
}

######################################

echo "<hr>";
teste();
echo "<hr>";
teste();
echo "<hr>";
quadrado();
