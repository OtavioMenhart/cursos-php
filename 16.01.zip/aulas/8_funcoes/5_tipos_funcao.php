<?php 
##############################################
### VALOR PADR�O ##################
//N�o colocar padr�o � esquerda, sempre � direita
//Posso ter quantos eu quiser

###################################################
#########passar ARGUMENTOS por refer�ncia##############
//Um argumento passado por refer�ncia faz com que a vari�vel que est� no argumento
//seja modificada fora da fun��o



##################################################
####Fun��o aninhada###############################


/* Vari�veis fun�oes - sempre que o PHP encontra uma vari�vel seguida de parenteses, procura uma fun�ao culo nome � dado pelo valor da vari�vel e executa essa fun�ao.
 */
 function ola(){
 	echo "esta fun�ao � a fun�ao:". _FUNCTION_;
 }

 #######################################################################################



/////////////////////////////////////////////////////////////////////////////////////////
?>