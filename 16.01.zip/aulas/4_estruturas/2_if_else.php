<?php
$nota = 8;

echo "<hr>";

if($nota >= 7){
	echo "aprovado<br>";
}
else{
	echo "reprovado<br>";
}

echo "<hr>";