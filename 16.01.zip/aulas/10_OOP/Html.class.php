<?php
class Html
{
		function __construct()
		{
				echo "Ol� eu sou a classe HTML<br>";
		}
}