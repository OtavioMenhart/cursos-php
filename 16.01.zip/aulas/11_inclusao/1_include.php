<?php 
include 'lista.php';
?>


<!doctype html>
<html>
<head>
<title>Estudo de vari�vel</title>
<meta charset="utf-8" />
</head>
<body>

<?php 
include 'lista.php';
?>
<hr>

<!-- quando acontece um erro na inclusao retorna um WARNING, porém continua com -->
<!-- o processamento da página -->

<?php 
include 'lista.php';
?>
<hr>

</body>
</html>