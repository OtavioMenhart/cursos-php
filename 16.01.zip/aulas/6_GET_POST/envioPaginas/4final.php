<?php 
extract($_GET);
?>

<!doctype html>
<html>
<meta charset="utf-8"/>
<head>
<title>Untitled</title>
</head>
<body>
CONFIRMADO<br>
<br>
Seu nome é <?=$nome?>!!!!<br>
Sua idade é <?=$idade?> anos!!!!
</body>
</html>
