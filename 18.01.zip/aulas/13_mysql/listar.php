<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<link href="css/estilos.css" rel="stylesheet" type="text/css">
</head>

<body style="padding:50px;">
<div >
    <div>
        
        
        
        <br /><br />
<table id="tabela" >
  <thead class="branco">
  
  <tr>
    <td>Identificação</td>
    <td >Nome</td>
    <td>telefone</td>
    <td>email</td>

    <td>sexo</td>
    <td>tipo</td>
    <td colspan="2">
   <a class="botao" href="inserir.php">Novo Contato</a>
   </td>
  </tr>
  </thead>
  

  <tr>
    <td >1</td>
    <td>nono nono nono</td>
    <td>9999 - 9999</td>
    <td>non@non.com</td>

    <td>m</td>
    <td>fam</td>
    <td><a class="botao" href="alterar.php">Alterar</a></td>
    <td><a class="botao" href="excluir.php">Excluir</a></td>
    
  </tr>
   <tr>
     <td>1</td>
    <td>nono nono nono</td>
    <td>9999 - 9999</td>
    <td>non@non.com</td>

    <td>m</td>
    <td>fam</td>
    <td><a class="botao" href="alterar.php">Alterar</a></td>
    <td><a class="botao" href="excluir.php">Excluir</a></td>
    
  </tr>
  <tr>
     <td>1</td>
    <td>nono nono nono</td>
    <td>9999 - 9999</td>
    <td>non@non.com</td>

    <td>m</td>
    <td>fam</td>
    <td><a class="botao" href="alterar.php">Alterar</a></td>
    <td><a class="botao" href="excluir.php">Excluir</a></td>
    
  </tr>
    <tr>
     <td>1</td>
    <td>nono nono nono</td>
    <td>9999 - 9999</td>
    <td>non@non.com</td>

    <td>m</td>
    <td>fam</td>
    <td><a class="botao" href="alterar.php">Alterar</a></td>
    <td><a class="botao" href="excluir.php">Excluir</a></td>
    
  </tr>
  </table>

	</div>
</div>
</body>
</html>
