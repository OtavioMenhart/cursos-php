<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
</body>
</html>http://www.codigomaster.com.br/desenvolvimento/crud-com-php-de-forma-simples-e-facil
http://php.net/manual/pt_BR/mysqli-stmt.bind-param.php