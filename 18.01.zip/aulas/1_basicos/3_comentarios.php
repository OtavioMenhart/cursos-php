<!doctype html>
<html>
<head>
<title>coment�rios</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<hr />

<?php
//tipo C, C++
print "coment�rio de linha em php";//na pr�pria linha

print "<hr>";

#do tipo unix
print "coment�rio de linha em php";#na mesma linha

print "<hr>";

/*
1a linha
2a linha
3a linha
*/

print "coment�rio de bloco";

?>
</body>
</html>
