<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; text/html; charset=iso-8859-1" />
</head>
<body>

<?php 
echo "Eu n�o matei Joana D'Arc";
echo "<br>";

echo 'Eu n�o gosto daquele "deputado", pois n�o me parece s�rio';

#################################################################
echo "<hr>";
echo 'Eu n�o matei Joana D\'Arc';
echo "<br>";

echo "Eu n�o gosto daquele \"deputado\", pois n�o me parece s�rio";

?>


</body>
</html>
