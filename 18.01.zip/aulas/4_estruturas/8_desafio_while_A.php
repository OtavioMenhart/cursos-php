<html>
<head>
<title>While desafio - A</title>
</head>
<body>
<ul>
	<li>banana</li>
	<li>uva</li>
	<li>pera</li>
	<li>maca</li>	
	<li>manga</li>
</ul>
</body>
</html>
