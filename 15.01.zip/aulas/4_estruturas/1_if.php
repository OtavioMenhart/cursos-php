<?php
$nota = 10;

if($nota == 10){
	echo "parabens<br>";
}

echo "<hr>";

if($nota == 10):
	echo "parabens<br>";
endif;

echo "<hr>";

if($nota == 10)
	echo "parabens<br>";
