<?php
$cont = 1;
while ($cont <= 3){
	echo "while<br>";
	$cont++;
}
echo "<hr>";

#######################################################

for($cont = 1; $cont <=3; $cont++){
	echo "for<br>";
}
echo "<hr>";

#######################################################

$cont = 1;
do{
	echo "Do-While<br>";
	$cont++;
}while($cont<=3);
