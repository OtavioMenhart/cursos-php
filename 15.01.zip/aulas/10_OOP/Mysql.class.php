<?php
class Mysql
{
		function __construct()
		{
				echo "Ol� eu sou a classe Mysql<br>";
		}
}