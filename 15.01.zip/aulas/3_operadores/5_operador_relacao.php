<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php 
//Operador dr rela��o ou Relacionais

$a = "30";
$b = 130;

//Vari�vel $a � igual a $b?
print "Vari�vel \$a � igual a \$B: " ;
print $a == $b;//1 = true
print "<hr>";


//Vari�vel $a � diferente a $b?
print "Vari�vel \$a � diferente a \$B: " ;
print $a != $b;
print "<hr>";

//Vari�vel $a � identica a $b?
print "Vari�vel \$a � identica a \$B: " ;
print $a === $b;//valor e tipo = null
print "<hr>";

//Vari�vel $a � N�O identica a $b?
print "Vari�vel \$a � N�O identica a \$B: " ;
print $a !== $b;//valor e tipo = null
print "<hr>";

//Vari�vel $a � maior a $b?
print "Vari�vel \$a � maior a \$B: " ;
print $a > $b;
print "<hr>";
 
 //Vari�vel $a � menor a $b?
print "Vari�vel \$a � menor a \$B: " ;
print $a < $b;
print "<hr>";
 
 //Vari�vel $a � maior ou igual a $b?
print "Vari�vel \$a � maior ou igual a \$B: " ;
print $a >= $b;
print "<hr>";
 
  //Vari�vel $a � menor ou igual a $b?
print "Vari�vel \$a � menor ou igual a \$B: " ;
print $a <= $b;
print "<hr>";

 ?>
</body>
</html>
