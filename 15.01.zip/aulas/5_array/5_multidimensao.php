<?php
$a['sp'][0]="Santos";
$a['sp'][1]="Campinas";
$a['sp'][2]="Itu";
$a['sp'][3]="Jau";
$a['rj'][0]="Buzios";
$a['rj'][1]="Niteroi";
$a['rj'][2]="Parati";
$a['mg'][0]="BH";
$a['mg'][1]="Pocos de CAldas";
$a['am'][0]="Manaus";

echo count($a);//4

var_dump($a);