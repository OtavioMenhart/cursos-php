<div class="centro">
<a href="htttp://www.uol.com.br" target="_blank">[ Inserir ] | </a>
<a href="../listar.php">[ Listar ] | </a>
<a href="../gerenciar.php">[ Gerenciar ] | </a>
<a href="../sair.php">[ Sair ]</a>
</div>
<hr />
