<?php
echo 8+16/4;//12
echo "<br>";
echo (8+16)/4;//6