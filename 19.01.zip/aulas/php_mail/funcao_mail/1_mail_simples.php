<?php 
$para="edupretel@gmail.com";
$assunto="Teste de PHP";
$mensagem="Isto é um teste de PHP";

mail($para,$assunto,$mensagem);
?>