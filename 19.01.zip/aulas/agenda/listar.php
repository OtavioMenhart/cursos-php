<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<link href="css/estilos.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="agenda">
<table width="727" align="center" class="tabela">
    <tr>
      <td colspan="7"><p ><span class="td">Agenda</span></p></td>
  </tr>
  <tr>
    <td width="92"><span class="td">Identificação</span></td>
    <td width="219"><span class="td">Nome</span></td>
    <td width="93"><span class="td">telefone</span></td>
    <td width="159"><span class="td">email</span></td>
    <td width="159"><span class="td">data inc</span></td>
    <td><span class="td">sexo &nbsp;</span></td>
    <td><span class="td">tipo &nbsp;</span></td>
  </tr>
  <tr>
    <td><span class="td">1</span></td>
    <td><span class="td">nono nono nono </span></td>
    <td><span class="td">9999 - 9999 </span></td>
    <td><span class="td">non@non.com</span></td>
    <td><span class="td">2011-03-12</span></td>
    <td width="69"><span class="td">m</span></td>
    <td width="69"><span class="td">fam</span></td>
  </tr>
  <tr>
    <td><span class="td">2</span></td>
    <td><span class="td">nana nana nana </span></td>
    <td><span class="td">8888 - 8888 </span></td>
    <td><span class="td">nan@nan.com</span></td>
    <td><span class="td">2011-03-12</span></td>
    <td><span class="td">f</span></td>
    <td><span class="td">esc</span></td>
  </tr>
  <tr>
    <td><span class="td">3</span></td>
    <td><span class="td">nene nene nene</span></td>
    <td><span class="td">4444 - 4444 </span></td>
    <td><span class="td">nen@nen.com</span></td>
    <td><span class="td">2011-03-12</span></td>
    <td><span class="td">t</span></td>
    <td><span class="td">tra</span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  </table>


</body>
</html>
