<div class="centro">
<a href="../inserir.php">[ Inserir ] | </a>
<a href="../listar.php">[ Listar ] | </a>
<a href="../gerenciar.php">[ Gerenciar ] | </a>
<a href="../sair.php">[ Sair ]</a>
</div>
<hr />
