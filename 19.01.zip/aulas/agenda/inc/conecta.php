<?php
$host = 'localhost';
$usuario="root";
$senha="";
$base="agenda";

$conn = mysqli_connect($host, $usuario, $senha, $base);
//$conn = new Mysqli($host, $usuario, $senha, $base);

//var_dump($conn);
