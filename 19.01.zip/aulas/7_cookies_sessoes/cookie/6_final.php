<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php 
###########################################################3
print "<hr>";
#####################################33
print "Esta � a Cookie: <br>";
print "<pre>";
print_r($_COOKIE);
print "</pre>";
print "<hr>";
?>

</body>
</html>
