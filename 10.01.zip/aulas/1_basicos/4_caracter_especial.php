<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php 
/*
 * \r \n \t s� funcionam entre aspas duplas
 * 
 * 
*/


echo "Isto divide em 3 linhas
Esta � a segunda linha
quebras de linha ser�o mostradas tamb�m
esta � a quarta linha&quot";

echo "\n\n<hr>\n\n";

echo "Isto divide em 3 linhas\n Esta � a segunda linha\n quebras de linha ser�o mostradas tamb�m\n esta � a quarta linha&quot";

echo "\n\n<hr>\n\n";

echo "Isto divide em 3 linhas
\tEsta � a segunda linha
\tquebras de linha ser�o mostradas tamb�m
\t\testa � a quarta linha&quot";

//Linguagem C nativa
//no Windows - char13 - quebra de linha
//32 espa�o
//8 backspace
//tableascii.com

?>


</body>
</html>
