<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?php 

/*
p1	p2	and	or	xor


*/

$a = 2;
$b = 3;
$c = 6;


print "<hr>";//and
print "<hr>";//and

print "<hr>";//or
print "<hr>";//or

print "<hr>";//xor



?>
</body>
</html>
