<!doctype html>
<html>
<head>
<title>Operadores de Incremento e Decremento </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?php 
$a = 4; // 4





 ?>

</body>
</html>
