<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php 

// O operador literal em php � o ponto

$a = "A casa ";
$b = "� bonita.";
$c = "Tenho ";
$d = 3;
$e = " cachorros";

 //concatena��o




 ?>

</body>
</html>
