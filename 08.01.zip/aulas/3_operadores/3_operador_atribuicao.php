<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php 
//o operador de atribui��o � o igual =

$nome = "Eduardo"; //atribuo a variavel nome o valor Eduardo
print "<hr>";

print "<hr>";


$total = 5;

//print "<hr>";


//print "<hr>";

//print $total;
//print "<hr>";

//print $total;
//print "<hr>";

/*
=
+=
-=
*=
/=
%=
.=
*/
 ?>
</body>
</html>