<!doctype html>
<html>
<head>
<title>coment�rios</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<hr />

<?php

print "coment�rio de linha em php";

print "<hr>";


print "coment�rio de linha em php";

print "<hr>";


print "coment�rio de bloco";

?>
</body>
</html>
