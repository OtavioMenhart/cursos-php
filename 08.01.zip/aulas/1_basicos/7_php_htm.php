<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; text/html; charset=iso-8859-1" />
</head>
<body>
<p style="color:#F00;font-family:Arial, Helvetica, sans-serif;font-size:36px">Edu Pretel</p>
<hr />
<p style="color:#F00;font-family:Arial, Helvetica, sans-serif;font-size:36px">Edu Pretel</p>
<hr />
<p style="color:#F00;font-family:Arial, Helvetica, sans-serif;font-size:36px">Edu Pretel</p>
<hr />
<p style="color:#F00;font-family:Arial, Helvetica, sans-serif;font-size:36px">Edu Pretel</p>
<hr />
</body>
</html>
