<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php 
/*
print() � uma constru��o da linguagem 

Mostra arg. Retorna TRUE em caso de sucesso ou FALSE em falhas. 
Pode ser usado em express�o ternaria.
*/


/*
echo()  n�o � obrigat�rio usar par�nteses
N�o � poss�vel usar echo() num contexto de fun��es variaveis, mas voc� pode usar print() no lugar dela. 
N�o Pode ser usado em express�o ternaria.
*/

// pesquisar php.net print
 
//$ret = echo "Hello World";
?>
</body>
</html>