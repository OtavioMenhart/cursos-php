<?php
/*
 "Defini��o"
 "espa�o na mem�ria ao qual eu me referencio atrav�s de um endere�o<br>"
 "locais usados para armazenar informa��es durante a execu��o do programa"

Regras
1 - Sempre antecedidas pelo caracter "$"(dolar)
2 - Come�a com uma letra ou o simbolo "_"
3 - N�o podem conter espa�os
4 - Sensitive Case - NOME <> nome <> Nome
5 - Validos - $USER ; $login; $_cidade ; $_UF;";
6 - n�o v�lidos - $2mes; $#dia
*/
?>
<!doctype html>
<html>
<head>
<title>Estudo de vari�vel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php
//declarando uma vari�vel

?>
</body>
</html>