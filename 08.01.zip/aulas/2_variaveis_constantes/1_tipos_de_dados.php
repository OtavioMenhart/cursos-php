<!doctype html>
<html>
<head>
<title>Tpos de Dados</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php

//$a = ;
//$b = ;
//$c = ;
//$d = ;
//$e = ;
//$f = ;

//print gettype($a);
//print is_integer($a)
//ap�s vers�o 4.2.0 - int
//print "<hr>";

//print gettype($b);
//print is_int($b)
//ap�s vers�o 4.2.0 - int
//print "<hr>";

//print gettype($c);
//entre vers�o 4.2.0 e 5.0.3 d� erro


//pode ser double, real, ou float - ponto no lugar da v�rgula
//ap�s vers�o 4.2.0 - float
//print "<hr>";

//print gettype($d);
//print is_string($d);
//print "<hr>";

//print gettype($e);



//print "<hr>";

//print gettype($f);


//print "<hr>";

?>

</body>
</html>
