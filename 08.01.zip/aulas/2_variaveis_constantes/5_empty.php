<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php 
//Estudo de empty - 

settype ($a,"string");
print gettype ($a);
//print $a;
print "<br>";
//print "Est� vazia: ";

print "<br>";
//print "N�o est� vazia: ";

print "<hr>";

//settype ($b,"string");
//print gettype ($b);
print "<br>";
//$b = "Edu";
//print $b;
print "<br>";
//print "Est� vazia: ";

print "<br>";
//print "N�o est� vazia: ";

print "<hr>";


//print $b;
print "<br>";
//print "Est� vazia: ";

print "<br>";
//print "N�o est� vazia: ";

print "<hr>";


?>
</body>
</html>
