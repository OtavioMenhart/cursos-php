<!doctype html>
<html>
<head>
<title>Settype_Gettype</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php 
//Estudo de Settype
//Declara vari�vel ou altera o tipo de dado

//settype ($a,string);
//print gettype ($a);
//print $a;
//print "<hr>";

//settype ($b,string);
//print gettype ($b);
//print "<br>";






?>
</body>
</html>
