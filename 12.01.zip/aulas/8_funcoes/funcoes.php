<?php
function quadrado($numero){
	//$numero = 5;
	$total = $numero * $numero;
	return  $total;
}
#######################################################

