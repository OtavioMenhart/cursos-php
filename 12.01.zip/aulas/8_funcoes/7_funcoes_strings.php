<?php 
define("HR","<hr>");
#####################################
//$palavra="EdUaRdO";
//$frase="esta � uma frase em php, esta � uma frase em php, esta � uma frase em php";
//$nome ="Eduardo Pretel Filho";
//$branco="            Edu              ";

//print $palavra;
print HR;

//print strtoupper($palavra);// para maiusculas
print HR;

//print strtolower($palavra);//para minusculas
print HR;

//print strrev($palavra);//para reverso
print HR;

//print strlen($palavra);//para tamanho
print HR;

//print ucfirst($frase);//para primeira letra da frase para mai�scula
print HR;

//print ucwords($frase);//para primeira letra de cada palavra para mai�scula
print HR;

//print ucfirst(strtolower(strrev($palavra)));//para reverso
print HR;

//print substr($nome,0,7);
print HR;
//print substr($nome,8,6);
print HR;
//print substr($nome,15);
print HR;

print HR;
//print $branco;
print HR;
//print ltrim($branco);
print HR;
//print rtrim($branco);
print HR;
//print trim($branco);
print HR;

//print htmlentities("Ma�� � <>");
print HR;
//print htmlspecialchars("Ma�� � <>");
print HR;


//print md5($palavra);
print HR;
//print md5(123);
print HR;

//$texto="Esta �� a primeira linha, \n Esta �� a segunda linha, \n Esta �� a terceira linha, \nEsta �� a quarta linha." ;
//print ;

//print nl2br($texto);
print HR;
//$texto='Eu n�o gosto "daquela" candidata';
print addslashes($texto);
//$texto="Eu n�o matei Joana D'arc";
print addslashes($texto);

############################################################################################3
//print str_replace("�","a","Ma��, an�o, pe�o, mam�o");
print "<br>";
//$procura=array("�","�","�","�","�","�");
//$acha=array("a","a","a","o","o","e");
//print str_replace($procura,$acha,"Ma�� � � � da v�v�");
?>