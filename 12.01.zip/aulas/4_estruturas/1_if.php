<?php
$nota = 8;

if($nota == 10){
	echo "vc � foda<br>";
}