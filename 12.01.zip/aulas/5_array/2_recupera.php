<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php 
$alunos = array("Aline","Anderson","denise","gilberto","eduardo","luis","Diego","lilica");
print "<hr>";

print "<hr>";
#################################################
//while


print "<hr>";
#######################################
//for
print "<hr>";
############################################
//array nominarivo

print "<hr>";
################################################
//foreach - reseta um array e move o ponteiro para o proximo indice a cada giro
//foraech somente com o VALOR

print "<hr>";
//foraech  com o INDICE e VALOR



print "<hr>";
#################################################




?>
</body>
</html>
