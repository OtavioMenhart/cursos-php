<?php 
require 'lista.php';
?>
<!doctype html>
<html>
<head>
<title>Estudo de variável</title>
<meta charset="utf-8" />
</head>
<body>
<?php 
require 'lista.php';
?>
<hr>

<?php 
/*
 * Quando acontece um erro na inclusao do arquivo
 * retorna eu erro to tipo FATAL ERROR que  interrompe  o processamento da pagina
 * */
//@require 'listassssssssss.php';//@ inibe o aviso de erro
require 'listassssssssss.php';
?>
</body>
</html>
<?php 
require 'lista.php';
?>