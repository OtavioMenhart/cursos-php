<?php 
include_once '../8_funcoes/funcoes.php';
include_once '../8_funcoes/funcoes.php';
//require_once '../8_funcoes/funcoes.php';
$a =  quadrado(7);
?>
<!doctype html>
<html>
<head>
<title>Estudo de variável</title>
<meta charset="utf-8" />
</head>
<body>
<?= quadrado(9) ?>
<hr>
<?= $a ?>

</body>
</html>
