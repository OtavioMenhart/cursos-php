<ul>
	<li>Amarelo</li>
	<li>Azul</li>
	<li>Aniz</li>
	<li>Anta</li>			
</ul>