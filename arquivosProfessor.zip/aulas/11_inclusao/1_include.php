<?php 
include 'lista.php';
?>
<!doctype html>
<html>
<head>
<title>Estudo de variável</title>
<meta charset="utf-8" />
</head>
<body>
<?php 
include 'lista.php';
?>
<hr>

<?php 
/*
 * Quando acontece um erro na inclusao do arquivo
 * retorna eu erro to tipo warming que nao interrompe  o processamento da pagina
 * */
@include 'listassssssssss.php';
?>
</body>
</html>
<?php 
include 'lista.php';
?>