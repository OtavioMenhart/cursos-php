<?php
$host = "localhost";
$user="root";
$password="";
$basedados="agenda";

/*
 //procedural style
$conn = mysqli_connect($host,$user,$password,$basedados);

*/
@$conn = new Mysqli($host,$user,$password,$basedados);

if($conn->connect_error){
	echo "Ocorreu um erro na conexao com o banco de dados<br>";
	exit;
}
$conn->set_charset('utf8');
/*
 function mysqli_connect($host,$user,$password,$basedados)
 {
 	return new Mysqli($host,$user,$password,$basedados);
 }
 * */