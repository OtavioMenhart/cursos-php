<?php
$a = fopen('www.txt','a+');
fwrite($a,"Impacta<br>\n");
echo gettype($a);