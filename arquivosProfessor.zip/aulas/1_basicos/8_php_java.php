<!doctype html>
<html>
<head>
<title>Escape</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<script type="text/javascript">
<!--
alert("\tOl� Eduardo! \n\nPrimeiro aviso");
//-->
</script>

<script type="text/javascript">
<!--
alert("\tOl� Eduardo! \n\nSegundo aviso");
//-->
</script>

<script type="text/javascript">
<!--
alert("\tOl� Eduardo! \n\nTerceiro aviso");
//-->
</script>

<script type="text/javascript">
<!--
alert("\tOl� Eduardo! \n\nQuarto aviso");
//-->
</script>

<script type="text/javascript">
<!--
alert("\tOl� Eduardo! \n\nQuinto aviso");
//-->
</script>
</body>
</html>
