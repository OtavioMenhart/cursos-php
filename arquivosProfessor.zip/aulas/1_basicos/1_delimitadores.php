<!doctype html>
<html>
<head>
<title>delimitadores</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php
//delimitadores di tipo PHP tags
//padr�o e deve ser utilizado
echo "Delimitadores do tipo PHP TAGS!!!!!<br>";
?>

<hr />

<?
//short open tags - configuravel e vem como padrao OFF
//desabuiltado em fun��o do XML
//n�o � necessaria habilita-la para utilizar o ALIAS do echo
echo "delimitadores do tipo short open tags<br>";
?>

<hr />

<%
//asp tags - desabilitado - foi depreciado na vers�o 7
echo "delimitadores do tipo ASP TAGS<br>";
%>

<hr />
<script language="php">
//linguagens visuais - nao configuravel
echo "delimitadores do tipo Linguagens visuais<br>";
</script>

<hr />
<!--  abaixo gerando o alias do echo do PHP -->
<?= "oi" ?>
</body>
</html>
