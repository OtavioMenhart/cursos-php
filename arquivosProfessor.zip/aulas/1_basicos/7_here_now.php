<?php
$nome = "Fabiana";

echo "
<p> Ol� $nome</p>
<p> Ol� \"$nome\"</p>
<p>\"Impacta\" qquer coisa</p>
";



echo "<hr>";
//sintaxe heredoc
//funciona como se string estivesse entre aspas duplas 
//e n�o preciso me preocupar cos aspas interas internas da string
echo <<<MICHEL
<p> Ol� $nome</p>
<p> Ol� "$nome"</p>
<p>"Impacta" qquer coisa</p>
MICHEL;
//sem aspas quer dizer aspas duplas
echo <<<"LISTA"
<p> Ol� $nome</p>
<p> Ol� "$nome"</p>
<p>"Impacta" qquer coisa</p>
LISTA;
echo "<hr>";
######################################
//sintexa nowdoc
echo <<<'LISTA'
<p> Ol� $nome</p>
<p> Ol� "$nome"</p>
<p>"Impacta" qquer coisa</p>
LISTA;

?>