<!doctype html>
<html>
<head>
<title>coment�rios</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<hr />

<?php
//tipo C, C++ windows
print "coment�rio de linha em php";//na propria linha

print "<hr>";

# do tipo Unix
print "coment�rio de linha em php";#na propria linha

print "<hr>";


print "coment�rio de bloco";
/*
1a linha
 2a linha
 3a linha
 4a linha
  */
?>
</body>
</html>
