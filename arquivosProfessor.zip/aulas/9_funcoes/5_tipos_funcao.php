<?php 
##############################################
### VALOR PADR�O ##################
//N�o colocar padr�o � esquerda, sempre � direita
//Posso ter quantos eu quiser
function aulas($aluno,$prof="Edu")
{
	echo "$aluno - $prof <br>";
}

aulas('Adilson');
aulas('Otavio');
aulas('Otavio','Sandra');
echo "<hr>";
###################################################
#########passar ARGUMENTOS por refer�ncia##############
//Um argumento passado por refer�ncia faz com que a vari�vel que est� no argumento
//seja modificada fora da fun��o
$nome = "Edu";
function formata(&$a)
{
	$a = "<span style=\"color:red;font-size:40px\">$a</span>";
	$a = "karol";
	echo $a;
}
formata($nome);
echo "<hr>";
//echo $a;
echo $nome;

##################################################
###################################


/* Vari�veis fun�oes - sempre que o PHP encontra uma vari�vel seguida de parenteses, procura uma fun�ao culo nome � dado pelo valor da vari�vel e executa essa fun�ao.
 */
 function ola(){
 	echo "esta funcao é a funcao:". __FUNCTION__;
 }
//ola();
$a = "ola";
$a();
 #######################################################################################
echo "<hr>";
$c = function()
{
	echo "sou a funcao anonima<br>";
};

$c();
/////////////////////////////////////////////////////////////////////////////////////////
?>