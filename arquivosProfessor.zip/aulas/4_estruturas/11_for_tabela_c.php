<?php 
include_once '../8_funcoes/funcoes.php';

?>
<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?= montaTabela(4,9) ?>
<hr>
<?= montaTabela(9,5) ?>
<hr>
<?= montaLista(['Michel','Francisco','Lucas','Adilson','Otavio']) ?>
</body>
</html>
