<?php
$cont = 1;
while($cont <= 3){
	echo "Impacta<br>";
	$cont++;
}

echo "<hr>";
###########################################
for($cont = 1;$cont <= 3;$cont++){
		echo "Impacta<br>";
}