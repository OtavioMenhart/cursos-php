<?php 
include_once '../8_funcoes/funcoes.php';
$tabela1 =  montaTabela(4,9) ;
$tabela2 = montaTabela(9,5);
$lista =  montaLista(['Michel','Francisco','Lucas','Adilson','Otavio']) ;
?>
<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?=$tabela1?>
<hr>
<?=$tabela2   ?>
<hr>
<?=$lista ?>
</body>
</html>
