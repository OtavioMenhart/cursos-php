<?php 
function montaTabela($num_linhas,$num_colunas)
{
			//parametrização
			//$num_linhas = 50;//essa variavel define o nº de linhas que a tabela terá
			//$num_colunas = 13;//essa variavel define o nº de coluna que a tabela terá
			
			
			$tabela =  "<table border=\"1\">\n";
			
			for($linha=1;$linha <= $num_linhas;$linha++){ 
					$tabela = $tabela . "\t<tr>\n";
					for($coluna=1;$coluna<=$num_colunas;$coluna++){	
							$tabela .= "\t\t<td> $linha.$coluna </td>\n";
					}		
					$tabela .= "\t</tr>\n";
			}
			
			$tabela .=  "</table>\n";
			return $tabela;
}


?>
<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?= montaTabela(4,9) ?>
<hr>
<?= montaTabela(9,5) ?>
</body>
</html>
