<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?php 
echo "<table border=\"1\">\n";

for($linha=1;$linha <= 4;$linha++){ 
		echo "\t<tr>\n";
		for($coluna=1;$coluna<=4;$coluna++){	
				echo "\t\t<td> $linha.$coluna </td>\n";
		}		
		echo "\t</tr>\n";
}

echo "</table>\n";
?>
</body>
</html>
