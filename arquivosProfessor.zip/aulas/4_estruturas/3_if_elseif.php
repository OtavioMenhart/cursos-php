<?php
$nota = 4;
echo"<hr>";

if($nota >= 7){
	echo "Aprovado<br>";
}elseif($nota<7 && $nota >5){
	echo "Recupera��o<br>";
}else{	
	echo "Reprovado<br>";
}

echo"<hr>";
