<?php 
$itens=['banana','uva','pera','maca','kiwi','laranja'];
$num_itens = count($itens);

$saida = "<ul>\n";
$i=0;
while($i<$num_itens){
			$saida = $saida. "\t<li>$itens[$i]</li>\n";
			$i++;
}
$saida .= "</ul>\n";//$saida = $saida. "</ul>\n";

?>
<html>
<head>
<title>While Lista</title>
<meta charset="utf-8" />
</head>
<body>

<?= $saida; ?>	
</body>
</html>