<?php
$nota = 8;
echo"<hr>";

if($nota >= 7){
	echo "Aprovado<br>";
}else{
	echo "Reprovado<br>";
}

echo"<hr>";