<?php
//um programa de 1 até 50 separado por "," -- 1,2,3,4,.....,48,49,50,
$parar = 20;
$cont = 1;
while($cont <= 50){
			echo "$cont, ";
			if($cont == $parar){
				  break;
			}
			$cont++;
}

echo "<hr>";
#########################################################

$pular = 30;
$cont = 1;
while($cont <= 50){
	
	if($cont == $pular){
			$cont++;
			continue;
	}
	echo "$cont, ";
	$cont++;
}

echo "<hr>";


