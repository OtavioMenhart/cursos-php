<?php 
$itens=['banana','uva','pera','maca'];
?>
<html>
<head>
<title>While Lista</title>
<meta charset="utf-8" />
</head>
<body>
<ul>
<?php 
$i=0;
while($i<4){
?>
	<li>banana</li>
<?php 
	$i++;
}
?>	
</ul>
</body>
</html>