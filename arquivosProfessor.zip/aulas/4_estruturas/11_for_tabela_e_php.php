<?php 
include_once '../8_funcoes/funcoes.php';
$tabela1 =  montaTabela(4,9) ;
$tabela2 = montaTabela(9,5);
$lista =  montaLista(['Michel','Francisco','Lucas','Adilson','Otavio']) ;
?>