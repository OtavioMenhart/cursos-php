<?php 
function montaLista($itens)
{		
		//parametrizaçãp
		//$itens=['banana','uva','pera','maca','kiwi','laranja'];
		$num_itens = count($itens);
		$saida = "<ul>\n";
		$i=0;
		while($i<$num_itens){
					$saida = $saida. "\t<li>$itens[$i]</li>\n";
					$i++;
		}
		$saida .= "</ul>\n";//$saida = $saida. "</ul>\n";
		return $saida;
}
$frutas = ['banana','uva','pera','maca','kiwi','laranja'];
$cores=['azul',"amarelo","preto","branco"];
?>
<html>
<head>
<title>While Lista</title>
<meta charset="utf-8" />
</head>
<body>

<?= montaLista($frutas); ?>	

<?= montaLista($cores); ?>	

<?= montaLista(['Jimmy','Corolla','Toro']); ?>	
</body>
</html>