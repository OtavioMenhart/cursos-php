<?php 
include_once '../8_funcoes/funcoes.php';
$frutas = ['banana','uva','pera','maca','kiwi','laranja'];
$cores=['azul',"amarelo","preto","branco"];
?>
<html>
<head>
<title>While Lista</title>
<meta charset="utf-8" />
</head>
<body>


<?= montaLista($frutas); ?>	

<?= montaLista($cores); ?>	

<?= montaLista(['Jimmy','Corolla','Toro']); ?>	

<p><?php echo "O quadrado de 5 é ".quadrado(5) ?></p>
</body>
</html>