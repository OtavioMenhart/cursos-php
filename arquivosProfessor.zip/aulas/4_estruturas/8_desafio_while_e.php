<?php 
$itens=['banana','uva','pera','maca','kiwi','laranja'];
$num_itens = count($itens);
?>
<html>
<head>
<title>While Lista</title>
<meta charset="utf-8" />
</head>
<body>

<?php
echo "<ul>\n";
$i=0;
while($i<$num_itens):
	echo "\t<li>$itens[$i]</li>\n";
	$i++;
endwhile;

echo "</ul>\n";
?>	
</body>
</html>