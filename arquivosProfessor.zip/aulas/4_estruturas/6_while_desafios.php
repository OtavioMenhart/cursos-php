<?php
//um programa de 1 até 50 separado por "," -- 1,2,3,4,.....,48,49,50,
$cont = 1;
while($cont <= 50){
	echo "$cont, ";
	$cont++;
}

echo "<hr>";
#########################################################
//um programa de 1 até 50 separado por "," -- 1, 2, 3, 4 ,.....,48, 49 e 50.
$cont = 1;
while($cont <= 50){
			if($cont <= 48){
					echo "$cont, ";
			}elseif($cont == 49)	{
					echo "$cont e ";
			}else{
					echo "$cont.";
			}
			$cont++;
}

echo "<hr>";
#########################################################
//um programa de 1 até 50 separado por "," -- 1,2,3,4,.....,48,49,50,
//numeros pares vermelhos e numeros impares pretos e multiplos de 5 verdes


$cont = 1;
while($cont <= 50){
			if($cont %5 == 0){
					$cor =  "color:#0F0";
			}elseif($cont % 2 == 0){
					$cor =  "color:#F00";
			}else{
					$cor = "color:#000";
			}
			echo "<span style='$cor'>$cont</span>, ";
			$cont++;
}

echo "<hr>";





