<?php
$itens=['banana','uva','pera','maca'];

echo sizeof($itens);
$i=0;
while($i<4){
	echo $itens[$i]."<br>";
	$i++;
}


/*
 <ul>
	<li>banana</li>
	<li>uva</li>
	<li>pera</li>
	<li>maca</li>			
</ul>
 * */