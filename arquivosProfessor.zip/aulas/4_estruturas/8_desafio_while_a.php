<html>
<head>
<title>While Lista</title>
<meta charset="utf-8" />
</head>
<body>
<ul>
	<li>banana</li>
	<li>uva</li>
	<li>pera</li>
	<li>maca</li>
</ul>
</body>
</html>