<?php
//quais sao os multiplos de 3 que estão entre 1 e 100
//faixa de valores - sei quantas vezes o laço vai girar
//posso fazer com o while, do_while e com o for
//for é o mais apropriado para faixa de valores
//para i de 1 até 100 passo 1 faça
//sei quantas vezes o laço vai girar
for($i=1;$i<=100;$i++){
		if($i % 3 == 0){
			echo "$i, ";
		}	
}
echo "<hr>";
//qual é o primeiro multiplo de 11,13, 17 
//não sei quantas vezes o laço vai girar
//variavel contadora e variavel controladora nao precisam ser a mesma variavel
$achei = false;//controladora
$cont = 1;//contadora
while($achei == false){
	if($cont % 11 == 0 && $cont % 13 == 0 && $cont % 17 == 0){
		echo $cont;
		//$achei = true;
		break;
	}
	$cont++;
}






