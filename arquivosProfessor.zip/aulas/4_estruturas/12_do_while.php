<?php
$cont = 10;
while($cont <= 3){
	echo "Impacta<br>";
	$cont++;
}

echo "<hr>";
###########################################
//executa com certeza ao menos uma vez as instruçoes
$cont = 10;

do{
	echo "Impacta<br>";
	$cont++;
}while($cont <= 3);