<?php 
include_once '11_for_tabela_e_php.php';
?>
<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?=$tabela1?>
<hr>
<?=$tabela2   ?>
<hr>
<?=$lista ?>
</body>
</html>
