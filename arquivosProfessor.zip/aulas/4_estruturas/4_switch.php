<?php
echo date('d/m/Y H:i:s');
echo "<br>";

$hoje = date("w");
echo $hoje;
echo "<br>";

switch($hoje){
	case 0:
		$dia = "domingo";
		break;
	case 1:
		$dia = "segunda_feira";
		break;
	case 2:
		$dia = "terça Feira";	
		break;
	case 3:
		$dia = "Quarta Feira";
		break;
	case 4:
		$dia = "Quinta Feira";
		break;
	case 5:
		$dia = "Sexta Feira";
		break;
	case 6:
		$dia = "Sábadp";
		break;
	default:
		$dia = "Valor invalido";	
}

echo $dia;
