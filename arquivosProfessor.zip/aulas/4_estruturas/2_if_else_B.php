<?php
/*
 *Possibilidades de isso retornar false
 $login não existir
 conteudo atribuido pode ser false, FALSE, NULL, null, '',"",0,settype
 TODO O RESTO RETORNARÁ TRUE
 NULL null  define('NULL',null);
 * */

//$login=0;
settype($login, 'string');
echo"<hr>";

if($login){
	echo "Logado<br>";
}else{
	echo "Nao Cadastrado<br>";
}

echo"<hr>";

if(!$login){
	echo "Nao Cadastrado<br>";
}else{
	echo "Logado<br>";
}