<?php
$nota = 8;

if($nota == 10){
	echo "Parabens, vc tirou a nota maxima<br>";
}

echo "<hr>";

if($nota == 10):
	echo "Parabens, vc tirou a nota maxima<br>";
endif;

echo "<hr>";
if($nota == 10)
	echo "Parabens, vc tirou a nota maxima<br>";
//se tiver somente uma instrução as chaves(delimitadores) são opcionais
//se nao tiver delimitadores(cahves) fara somente a primeira instrução

