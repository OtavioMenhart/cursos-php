<?php
//A classe descreve os objetos
//Os objetos s�o variaveis descritas pelas classes
class Pessoas
{
			public $nome;
			public $idade;
			public $sexo;
			public $nacionalidade;
			
			//metodo
			function __construct($a)
			{
				echo "Nasci!!!!!!!!!!!!!!!!!!!!!!! - e a \$a contem $a<br>";
			}
			function __destruct()
			{
				echo "Morri!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!<br>";
			}
			function teste()
			{
				echo "eu sou a função teste<br>";
			}
}
//operador new é o construtor de objetos
$edu = new Pessoas('Cida');
$edu->nome = "Eduardo";
$edu->idade = 57;
echo $edu->idade;
$edu->teste();
var_dump($edu);
###################################
echo "<hr>";
$francisco = new Pessoas('maria');
$francisco->nome = "francisco";
$francisco->idade = 30;
echo $francisco->idade;
var_dump($francisco);
###################################
echo "<hr>";
echo gettype($francisco);
echo is_object($francisco);//1
unset($francisco);
echo "<hr>";