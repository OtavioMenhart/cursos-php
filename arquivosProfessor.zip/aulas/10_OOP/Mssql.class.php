<?php
class Mssql
{
		function __construct()
		{
				echo "Ol� eu sou a classe Microsoft SQL<br>";
		}
}