<?php
class Mae
{
	//pde ser acessado publicamente
	public $um;
	
	//nao pode ser acessado pelo objeto - diferença se fara na herança
	protected $dois;
	private $tres;
	
	
	function semSegredo()
	{
		echo "Isso todos podem saber<br>";
	}
	protected function segredoFamiliar()
	{
		echo "Isso eu e minhas filhas acessamos<br>";
	}
	private function meuSegredo()
	{
		echo "Isso somente ue sei<br>";
	}
	public function contaTudo()
	{
		$this->segredoFamiliar();
		$this->meuSegredo();
	}
}

$a = new Mae();
var_dump($a);
$a->semSegredo();

//$a->segerdoFamiliar();//Fatal error: Call to undefined method Mae::segerdoFamiliar() 
//$a->meuSegredo();//Fatal error: Call to private method Mae::meuSegredo() 

$a->contaTudo();