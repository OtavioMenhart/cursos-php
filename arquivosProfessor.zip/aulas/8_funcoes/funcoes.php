<?php
function quadrado($numero)
{
	//$numero = 5;
	$total = $numero*$numero;
	return $total;
}
###############################################
function montaLista($itens)
{
	//parametrizaçãp
	//$itens=['banana','uva','pera','maca','kiwi','laranja'];
	$num_itens = count($itens);
	$saida = "<ul>\n";
	$i=0;
	while($i<$num_itens){
		$saida = $saida. "\t<li>$itens[$i]</li>\n";
		$i++;
	}
	$saida .= "</ul>\n";//$saida = $saida. "</ul>\n";
	return $saida;
}
###################################################
function montaTabela($num_linhas,$num_colunas)
{
	//parametrização
	//$num_linhas = 50;//essa variavel define o nº de linhas que a tabela terá
	//$num_colunas = 13;//essa variavel define o nº de coluna que a tabela terá
		
		
	$tabela =  "<table border=\"1\">\n";
		
	for($linha=1;$linha <= $num_linhas;$linha++){
		$tabela = $tabela . "\t<tr>\n";
		for($coluna=1;$coluna<=$num_colunas;$coluna++){
			$tabela .= "\t\t<td> $linha.$coluna </td>\n";
		}
		$tabela .= "\t</tr>\n";
	}
		
	$tabela .=  "</table>\n";
	return $tabela;
}
################################################
function montaSelect($name,$itens)
{
	//$itens = ['sp'=>'São Paulo','rj'=>"Rio de Janeiro",'pa'=>'Para','ac'=>'Acre','pr'=>'Paraná'];
	//$name = "uf";
		
	$saida = "<select name=\"$name\" id=\"$name\">\n";
	foreach ($itens as $value => $label){
		$saida = $saida . "\t<option value=\"$value\">$label</option>\n";
	}
	$saida .= "</select>\n";
		
	return $saida;
}