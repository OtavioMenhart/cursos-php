<?php 
function teste()
{
	echo "Ola eu sou a funcao teste<br>";
}
function quadrado()
{
	$numero = 5;
	$total = $numero*$numero;
	echo $total;
}
/*
 * ( ! ) Fatal error: Cannot redeclare quadrado() (previously declared in C:\wamp\www\aulas\8_funcoes\1_funcoes.php:6) 
function quadrado()
{
	$numero = 5;
	$total = $numero*$numero;
	echo $total;
}
*/
############################################
echo "<hr>";
teste();
echo "<hr>";
teste();
quadrado();
echo "<hr>";
quadrado();