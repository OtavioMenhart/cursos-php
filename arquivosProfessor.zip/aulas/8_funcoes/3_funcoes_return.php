<?php 
function quadrado($numero)
{
	//$numero = 5;
	$total = $numero*$numero;
	return $total;
}

##########################################
echo "<hr>";
echo quadrado(6);
echo "<hr>";
$c = quadrado(10);
var_dump($c);
echo "<hr>";
$a = quadrado(quadrado(5)+quadrado(10));
echo $a;