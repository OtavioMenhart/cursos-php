<?php 
setcookie('nome','Popozuda',time()+80000);
setcookie('escola','Ombro',time()+80000);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert title here</title>
</head>
<body>
<form action="2_recebe.php?nome=Karol&escola=fuk&idade=25&cabelo=rosa" method="post">
		Nome:<input type="text" name='nome'>
		<br>
		Escola:<input type="text" name='escola'>
		<br>
		Idade:<input type="text" name='idade'>
		<br><input type="submit">
</form>
</body>
</html>