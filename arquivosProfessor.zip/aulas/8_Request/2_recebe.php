<?php
session_start();
$_SESSION['nome']="Bela Recatada e do Lar";

var_dump(get_defined_vars());