<!doctype html>
<html>
<head>
<title>Untitled</title>
</head>
<body>

<form  method="post" action="4_recebe_post.php">
Digite aqui seu nome:<input type="text" name="nome" value="Edu" ><br>
Digite aqui sua idade:<input type="text" name="idade" value="57"><br><br>
<input type="submit" name="botao" value="Enviar">
</form>

</body>
</html>
