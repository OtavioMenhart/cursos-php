<?php 
$nome="Karol Comka";
$idade=24;
$curso="Lala";
?>
<!doctype html>
<html>
<head>
<title>envia get link</title>
</head>
<body>
<a href="1_recebe_get.php?nome=Edu&idade=57&curso=Corte e Costura">Clique aqui para enviar</a>
<hr>
<a href="1_recebe_get.php?nome=<?=$nome ?>&idade=<?=$idade ?>&curso=<?=$curso ?>">Clique aqui para enviar</a>
</body>
</html>
