<!doctype html>
<html>
<head>
<title>Untitled</title>
</head>
<body>
CONFIRMADO<br>
<br>
Seu nome � <?= $_GET['nome'] ?>!!!!<br>
Sua idade � <?= $_GET['idade'] ?> anos!!!!
</body>
</html>
