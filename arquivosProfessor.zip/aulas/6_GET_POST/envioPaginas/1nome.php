<?php
var_dump($_GET); 
/*
 $nome=$_GET['nome'];
 $idade = $_GET['idade'];
 * */

extract($_GET);//$nome="edu"   $idade=15

?><!doctype html>
<html>
<head>
<title>DIGITE SEU NOME</title>
<meta charset="utf-8" />
</head>
<body>
<form action="2idade.php" method="post">

Digite seu nome:
<input type="text" name="nome" value="<?=$nome ?>">
<input type="hidden" name="idade" value="<?=$idade ?>">
<input type="submit">



</form>
</body>
</html>
