<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta charset="utf-8" />
</head>
<body>

<?php 
//o operador de atribui��o � o igual =

$nome = "Eduardo"; //atribuo a variavel nome o valor Eduardo
echo $nome;
print "<hr>";
$nome = $nome . " Pretel";
echo $nome;
print "<hr>";
$nome .= ' Filho';//$nome = $nome .  ' Filho'
echo $nome;
print "<hr>";

####################################################
$total = 5;
echo $total;//5
print "<hr>";
$total = $total + 10;
echo $total ;//15
print "<hr>";
$total += 10;//$total = $total + 10;
print $total;//25



/*
=
+=
-=
*=
/=
%=
.=
*/
 ?>
</body>
</html>