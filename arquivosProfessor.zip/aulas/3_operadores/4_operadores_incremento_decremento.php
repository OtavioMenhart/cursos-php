<!doctype html>
<html>
<head>
<title>Operadores de Incremento e Decremento </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?php 
$a = 4; // 4
echo $a;//4

$a++;//$a = $a + 1;    //   $a +=1  // 5
echo $a;

++$a;//6
echo $a;//6

echo $a++;//printar 6 em seguida atribuirá 7 à variavel 
echo $a;//7

echo ++$a;//atribuira 8 à variavel e depois imprimirá 8

$a--;//7
echo $a;//7

--$a;//6
echo $a;//6

echo $a--;//printar 6 em seguida atribuirá 5 à variavel 
echo $a;//5

echo --$a;//atribuira 4 à variavel e depois imprimirá 4
 ?>

</body>
</html>
