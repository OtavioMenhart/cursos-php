<?php
$nota = 8;
echo"<hr>";

if($nota >= 7){
	echo "Aprovado<br>";
}else{
	echo "Reprovado<br>";
}

echo"<hr>";

echo ($nota >= 7);//retornaa true ou false

echo"<hr>";

echo ($nota >= 7)?("Aprovado"):("Reprovado");