﻿<html>
	<head>
		<title>OI</title>
	</head>
	<body>
		<p>
			Data Atual
		</p>
		<p>
			<?php echo date("d/m/Y H:i:s") ?>
		</p>	
	</body>

</html>