﻿<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php 
########################
//ordenado de forma explicita

//print "<hr />";
####################################################
//ordenado de forma implicita

print"<pre>";

print"</pre>";
#####################################################
//funcao array de forma explicita


print"<pre>";

print"</pre>";
#####################################################
//funcao array de forma implicita


print"<pre>";

print"</pre>";
############################
//Array Nominativo - por padrao usar aspas simples, porem funciona sem aspas
/* 
print $escola[impacta] - retoerna ero em alguns servidores que entendera que impacta é uma constante

//variavel interpolada
print "$escola[impacta]" - o array inteiro entra aspas - nao usar aspas no indice

//variavel nao interpolada
print $escola["impacta"] - a variavel nao tem aspas - quem tem aspas é o indice

padrao - variavel nao interpolada com aspas SIMPLES no indice
print $escola['impacta']
 */

print"<pre>";

print"</pre>";

#####################################################
//funcao array para nominativos

print"<pre>";

print"</pre>";
#####################################################
//funcao para criar array a partir dr uma string

print"<pre>";

print"</pre>";

?>
</body>
</html>