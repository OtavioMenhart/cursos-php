<!doctype html>
<html>
<head>
<title>delimitadores</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php

?>

<hr />

<?

?>

<hr />

<%

%>

<hr />




</body>
</html>
