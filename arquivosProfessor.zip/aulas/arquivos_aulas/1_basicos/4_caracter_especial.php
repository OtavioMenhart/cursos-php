<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>




Isto divide em 3 linhas
Esta � a segunda linha
quebras de linha ser�o mostradas tamb�m
esta � a quarta linha&quot;


//Linguagem C nativa
//no Windows - char13 - quebra de linha
//32 espa�o
//8 backspace
//tableascii.com



</body>
</html>
