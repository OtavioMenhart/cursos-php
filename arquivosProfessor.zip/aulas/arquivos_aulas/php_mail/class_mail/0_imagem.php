<?php
$mensagem =   "<table style=\"display: inline-table;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"480\">";

$mensagem .=   "<tr>";
$mensagem .=   "<td><img style=\"display:block\" src=\"http://www.edupretel.com.br/icaro/imagens/spacer.gif\" width=\"197\" height=\"1\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" src=\"http://www.edupretel.com.br/icaro/imagens/spacer.gif\" width=\"153\" height=\"1\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" src=\"http://www.edupretel.com.br/icaro/imagens/spacer.gif\" width=\"130\" height=\"1\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" src=\"http://www.edupretel.com.br/icaro/imagens/spacer.gif\" width=\"1\" height=\"1\" alt=\"\" /></td>";
$mensagem .=   "</tr>";

$mensagem .=   "<tr>";
$mensagem .=   "<td rowspan=\"2\"><img style=\"display:block\" name=\"icaro_r1_c1\" src=\"http://www.edupretel.com.br/icaro/imagens/icaro_r1_c1.jpg\" width=\"197\" height=\"135\" id=\"icaro_r1_c1\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" name=\"icaro_r1_c2\" src=\"http://www.edupretel.com.br/icaro/imagens/icaro_r1_c2.jpg\" width=\"153\" height=\"128\" id=\"icaro_r1_c2\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" name=\"icaro_r1_c3\" src=\"http://www.edupretel.com.br/icaro/imagens/icaro_r1_c3.jpg\" width=\"130\" height=\"128\" id=\"icaro_r1_c3\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" src=\"http://www.edupretel.com.br/icaro/imagens/spacer.gif\" width=\"1\" height=\"128\" alt=\"\" /></td>";
$mensagem .=   "</tr>";
 $mensagem .=   "<tr>";
$mensagem .=   "<td rowspan=\"2\"><img style=\"display:block\" name=\"icaro_r2_c2\" src=\"http://www.edupretel.com.br/icaro/imagens/icaro_r2_c2.jpg\" width=\"153\" height=\"112\" id=\"icaro_r2_c2\" alt=\"\" /></td>";
$mensagem .=   "<td rowspan=\"2\"><img style=\"display:block\" name=\"icaro_r2_c3\" src=\"http://www.edupretel.com.br/icaro/imagens/icaro_r2_c3.jpg\" width=\"130\" height=\"112\" id=\"icaro_r2_c3\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" src=\"http://www.edupretel.com.br/icaro/imagens/spacer.gif\" width=\"1\" height=\"7\" alt=\"\" /></td>";
$mensagem .=   "</tr>";
$mensagem .=   "<tr>";
 $mensagem .=   "<td><img style=\"display:block\" name=\"icaro_r3_c1\" src=\"http://www.edupretel.com.br/icaro/imagens/icaro_r3_c1.jpg\" width=\"197\" height=\"105\" id=\"icaro_r3_c1\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" src=\"http://www.edupretel.com.br/icaro/imagens/spacer.gif\" width=\"1\" height=\"105\" alt=\"\" /></td>";
$mensagem .=   "</tr>";
$mensagem .=   "<tr>";
$mensagem .=   "<td><img style=\"display:block\" name=\"icaro_r4_c1\" src=\"http://www.edupretel.com.br/icaro/imagens/icaro_r4_c1.jpg\" width=\"197\" height=\"120\" id=\"icaro_r4_c1\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" name=\"icaro_r4_c2\" src=\"http://www.edupretel.com.br/icaro/imagens/icaro_r4_c2.jpg\" width=\"153\" height=\"120\" id=\"icaro_r4_c2\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" name=\"icaro_r4_c3\" src=\"http://www.edupretel.com.br/icaro/imagens/icaro_r4_c3.jpg\" width=\"130\" height=\"120\" id=\"icaro_r4_c3\" alt=\"\" /></td>";
$mensagem .=   "<td><img style=\"display:block\" src=\"http://www.edupretel.com.br/icaro/imagens/spacer.gif\" width=\"1\" height=\"120\" alt=\"\" /></td>";
$mensagem .=   "</tr>";
$mensagem .=   "</table>";
echo $mensagem;
?>
