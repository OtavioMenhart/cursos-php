<!doctype html>
<html>
<head>
<title>DIGITE SEU NOME</title>
</head>
<body>
<form action="" method="">

Digite seu nome:
<input type="text" name="nome">
<input type="submit">



</form>
</body>
</html>
