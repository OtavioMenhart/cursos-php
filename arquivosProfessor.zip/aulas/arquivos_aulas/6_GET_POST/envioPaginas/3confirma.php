<!doctype html>
<html>
<head>
<title>CONFIRMA��O</title>
</head>
<body>
<p>Ol� Fulano!!!<br>
  <br>

Voc� tem 35 anos!!!<br>
<br>
<br>

Confirma essas informa��es?</p>
<p>&nbsp;</p>
<p>&nbsp;</p>



<a href="4final.php">SIM </a>
<hr>
<a href="1nome.php">N�O</a>


</body>
</html>
