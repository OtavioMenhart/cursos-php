<!doctype html>
<html>
<head>
<title>envia get link</title>
</head>
<body>
Clique aqui para enviar
</body>
</html>
