<!doctype html>
<html>
<head>
<title>Untitled</title>
</head>
<body>

<form  method="" action="">
Digite aqui seu nome:<input type="text" name="nome"><br>
Digite aqui sua idade:<input type="text" name="idade"><br><br>
<button type="submit">Enviar</button>
</form>

</body>
</html>
