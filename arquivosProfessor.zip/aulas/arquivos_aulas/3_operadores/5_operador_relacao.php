<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php 
//Operador dr rela��o ou Relacionais

$a = "";
$b = "";

//Vari�vel $a � igual a $b?
print "Vari�vel \$a � igual a \$B: " ;

print "<hr>";


//Vari�vel $a � diferente a $b?
print "Vari�vel \$a � diferente a \$B: " ;

print "<hr>";

//Vari�vel $a � identica a $b?
print "Vari�vel \$a � identica a \$B: " ;

print "<hr>";

//Vari�vel $a � maior a $b?
print "Vari�vel \$a � maior a \$B: " ;

print "<hr>";
 
 //Vari�vel $a � menor a $b?
print "Vari�vel \$a � menor a \$B: " ;

print "<hr>";
 
 //Vari�vel $a � maior ou igual a $b?
print "Vari�vel \$a � maior ou igual a \$B: " ;

print "<hr>";
 
  //Vari�vel $a � menor ou igual a $b?
print "Vari�vel \$a � menor ou igual a \$B: " ;

print "<hr>";

 ?>
</body>
</html>
