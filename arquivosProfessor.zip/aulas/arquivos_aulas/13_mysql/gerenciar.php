<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<link href="css/estilos.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="agenda">
  <table width="564" border="1" align="center" cellspacing="0" bordercolor="#000000" bgcolor="#FFFFFF">
    <tr>
      <td colspan="5"><p align="center">Agenda</p></td>
    </tr>
    <tr>
      <td width="92"><div align="center">Identificação</div></td>
      <td width="219"><div align="center">Nome</div></td>
      <td width="93"><div align="center">telefone</div></td>
      <td colspan="2"> <div align="center"><a href="inserir.php">Inserir</a></div></td>
    </tr>
    <tr>
      <td><div align="center">1</div></td>
      <td>nono nono nono </td>
      <td>9999 - 9999 </td>
      <td width="69"><div align="center">alterar</div></td>
      <td width="69"><div align="center">excluir</div></td>
    </tr>
    <tr>
      <td><div align="center">2</div></td>
      <td>nana nana nana </td>
      <td>8888 - 8888 </td>
      <td><div align="center">alterar</div></td>
      <td><div align="center">excluir</div></td>
    </tr>
    <tr>
      <td><div align="center">3</div></td>
      <td>nene nene nene</td>
      <td>4444 - 4444 </td>
      <td><div align="center">alterar</div></td>
      <td><div align="center">excluir</div></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</div>
<p align="center">&nbsp;</p>
</body>
</html>
