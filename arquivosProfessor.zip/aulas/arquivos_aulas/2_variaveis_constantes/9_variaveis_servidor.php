<!doctype html>
<html>
<head>
<title>Estudo de vari&aacute;vel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php 

?>
</body>