<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php 
$alunos = array("Aline","Anderson","denise","gilberto","eduardo","luis","Diego","lilica",'Francisco','Adilson');
print "<hr>";
var_dump($alunos);
echo count($alunos);
echo "<br>";
echo sizeof($alunos);
print "<hr>";
#######################################
//for
for($i=0;$i< sizeof($alunos) ;$i++){
	echo "\$alunos[$i] = $alunos[$i] <br>";
}

print "<hr>";
############################################
//array nominarivo
$regentes = ['sol'=>"Leao",'lua'=>"Cancer",'marte'=>"Aries",'venus'=>"Touro"];
/*
 $regentes['sol'] = 'Leao';
  $regentes['lua'] = 'Cancer';
 * */
var_dump($regentes);

print "<hr>";
################################################
//foreach - reseta um array e move o ponteiro para o proximo indice a cada giro
//foraech somente com o VALOR
foreach($regentes as $valor){
		echo "$valor <br>";
}

print "<hr>";
//foraech  com o INDICE e VALOR
foreach($regentes as $chave=>$valor){
		echo "$chave - $valor <br>";
}


print "<hr>";
#################################################




?>
</body>
</html>
