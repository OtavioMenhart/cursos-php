﻿<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php 
########################
//ordenado de forma explicita
$cores[0]='Azul';
$cores[1]="Amarelo";
$cores[2]="Roxo";
$cores[3]="Preto";

echo $cores;//nao pode ser printado um array
var_dump($cores);
print"<pre>";
print_r($cores);
print"</pre>";
print "<hr />";

$cor[100]='Azul';
$cor[25]="Amarelo";
$cor[250]="Roxo";
$cor[1]="Preto";
var_dump($cor);
echo "<hr>";
####################################################
//ordenado de forma implicita
$cursos[]="Php";
$cursos[]="MySql";
//$cursos[]="Html";
$cursos[]="JavaScript";
$cursos[]="CSS";

var_dump($cursos);

#####################################################
//construtor array de forma explicita
$moto = array(0=>'Fazer 250',15=>'CB 300',8=>'Ninja',6=>'HD');
var_dump($moto);

#####################################################
//funcao array de forma implicita
$carro = array('Jimmy','Corolla','Toro','Ka');;
var_dump($carro);


############################
//Array Nominativo - por padrao usar aspas simples, porem funciona sem aspas em ambiente de produção
/* 
print $escola[impacta] - retoerna ero em alguns servidores que entendera que impacta é uma constante

//variavel interpolada
print "$escola[impacta]" - o array inteiro entra aspas - nao usar aspas no indice

//variavel nao interpolada
print $escola["impacta"] - a variavel nao tem aspas - quem tem aspas é o indice

padrao - variavel nao interpolada com aspas SIMPLES no indice
print $escola['impacta']
 */
$escola['impacta']="Livres";
$escola['FIT']="Superiores";
$escola['senac']="Tecnicos";
var_dump($escola);
echo $escola[impacta];
echo "<br>";
echo $escola['impacta'];
echo "<br>";
echo $escola["impacta"];
echo "<br>";
echo "O nome da escola que oferece cursos LIVRES  é impacta";
echo "<br>";
echo "O nome da escola que oferece cursos ". $escola['impacta'] . " é impacta";
echo "<br>";
echo "O nome da escola que oferece cursos ". $escola["impacta"] . " é impacta";
echo "<br>";
//INTERPOLAÇÃO DE VARIAVEL
echo "O nome da escola que oferece cursos $escola[impacta]  é impacta";
echo "<br>";
//INTERPOLAÇÃO DE VARIAVEL - 5,4
echo "O nome da escola que oferece cursos {$escola['impacta']}  é impacta";//padrao
echo "<br>";
//INTERPOLAÇÃO DE VARIAVEL - 5,4
echo "O nome da escola que oferece cursos {$escola["impacta"]}  é impacta";
echo "<hr>";
#####################################################
//construtor array para nominativos
$ruas = array('avenida'=>"Paulista",'rua'=>"Pamplona",'alameda'=>"Santos",'praca'=>"Oswaldo Cruz");
var_dump($ruas);
echo "<hr>";
#####################################################
//sintaxe "JSON"
$planetas = ['sol','lua','marte','venus'];
var_dump($planetas);
echo "<hr>";

$regentes = ['sol'=>"Leao",'lua'=>"Cancer",'marte'=>"Aries",'venus'=>"Touro"];
var_dump($regentes);
echo "<hr>";

//funcao para criar array a partir dr uma string

$alunos = "Adilson,Otavio,Francisco,Lucas,Michel";
var_dump($alunos);
$alunos2 = explode(",", $alunos);
var_dump($alunos2);


?>
</body>
</html>