<?php 
include_once '../8_funcoes/funcoes.php';


$uf = ['sp'=>'São Paulo','rj'=>"Rio de Janeiro",'pa'=>'Para','ac'=>'Acre','pr'=>'Paraná'];
$cores = ['amarelo','azul','verde','vermelho'];
?>
<!doctype html>
<html>
<head>
<title>For</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<form>
<?= montaSelect('uf',$uf) ?>
<hr>
<?= montaSelect('colors',$cores) ?>
<hr>
<?= montaTabela(20, 7) ?>
<hr>
<?= montaLista($cores) ?>
<hr>
<hr>
 </form>
</body>
</html>
