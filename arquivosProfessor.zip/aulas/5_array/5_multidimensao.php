<?php
$a['sp'][0]="Santos";
$a['sp'][1]="Campinas";
$a['sp'][2]="Itu";
$a['sp'][3]="Jau";
$a['rj'][0]="Buzios";
$a['rj'][1]="Niteroi";
$a['rj'][2]="Parati";
$a['mg'][0]="BH";
$a['mg'][1]="Pocos de CAldas";
$a['am'][0]="Manaus";

echo count($a);//4
echo "<br>";
echo count($a,true);//4
var_dump($a);
echo $a['sp'][0];//Santos
echo count($a['sp']);
echo "<hr>";
#############################
foreach($a as $key=>$valor){
	@print "$key - $valor <br>";
}

echo "<hr>";
foreach($a['sp'] as $key=>$valor){
	@print "$key - $valor <br>";
}

#########################################
echo "<hr>";
foreach($a as $key=>$valor){
	foreach($valor as $ind => $cont){
		@print "$key - $ind - $cont <br>";
	}	
}

