<?php 
echo getenv('REMOTE_ADDR' );
echo "<hr>";
echo $_SERVER['REMOTE_ADDR' ];
echo "<hr>";
$aluno="Lucas";
var_dump(get_defined_vars());



?>