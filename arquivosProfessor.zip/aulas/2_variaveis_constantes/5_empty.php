<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<?php 
//Estudo de empty - 

settype ($a,"string");
print gettype ($a);//string
print $a;
print "<hr>";
print "Est� vazia: ";
print empty($a);//1
print "<br>";
print "N�o est� vazia: ";
print !empty($a);//NULL
print "<hr>";

settype ($b,"string");
print gettype ($b);//string
print "<br>";
$b = "Edu";
print $b;//Edu
print "<br>";
print "Est� vazia: ";
print empty($b);//null
print "<br>";
print "N�o est� vazia: ";
print !empty($b);//1
print "<hr>";




?>
</body>
</html>
