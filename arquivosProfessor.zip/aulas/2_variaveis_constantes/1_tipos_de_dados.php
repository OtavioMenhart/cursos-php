<!doctype html>
<html>
<head>
<title>Tpos de Dados</title>
<meta charset="utf-8" />
</head>
<body>

<?php
/*
 * Tipos de dados
 * 
 * Tipo é relacioando ao DADO e não à variavel
 * 
 * 3 grupos
 * 
 * Tipos Simples - relacionado à dados primitivos
 * 			A - Numerico -> Inteiros e Ponto flutuante
 * 			B - Caracteres - Strings
 * 			C - Booleano - TRUE ou FALSE
 * 
 * Tipos Compostos - relacionado à estrutura da Variavel
 * 			A - Array
 * 			B - Objetos
 * 
 * Tipos Especiais
 * 			A  - Resource
 * 			B - NULL
 * 
 * */
$a = 52;
$b =  -65;
$c = 98123.45;
$d = "Impacta";
$e = true;//TRUE é uma constante que contem o dado primitivo true
$f = false;

print gettype($a);//integer
print is_integer($a);//verdadeiro -> 1    Falso-> null
print is_int($a);//após versão 4.2.0 - int PADRÃO

print "<hr>";

print gettype($b);
print is_int($b);
//ap�s vers�o 4.2.0 - int
print "<hr>";

print gettype($c);
print is_double($c);//entre vers�o 4.2.0 e 5.0.3 d� erro
print is_float($c);//padrao
print is_real($c);
//pode ser double, real, ou float - ponto no lugar da v�rgula
//ap�s vers�o 4.2.0 - float
print "<hr>";

print gettype($d);//string
print is_string($d);//1
print "<hr>";

print gettype($e);//boolean
//print is_boolean($e); //não existe
print is_bool($e);//1

print "<hr>";

print gettype($f);
print is_bool($f);//1

print "<hr>";

?>

</body>
</html>
