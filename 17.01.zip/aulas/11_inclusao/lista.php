<ul>
	<li>amarelo</li>
	<li>vermelho</li>
	<li>verde</li>
	<li>preto</li>
</ul>