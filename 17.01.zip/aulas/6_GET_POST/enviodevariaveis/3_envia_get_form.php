<!doctype html>
<html>
<head>
<title>Untitled</title>
</head>
<body>

<form  method="get" action="1_recebe_get.php">
Digite aqui seu nome:<input type="text" name="nome" value="Otavio"><br>
Digite aqui sua idade:<input type="text" name="idade" placeholder="digite sua idade"><br><br>
<input type="submit" name="botao" value="Enviar"/>
</form>

</body>
</html>
