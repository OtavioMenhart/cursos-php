<?php 
include_once '../8_funcoes/funcoes.php';
$tabela1 = montaTabela(2,2);
$tabela2 = montaTabela(4,4);
$lista = montaLista(['Michel', 'Otávio', 'Lucas', 'Francisco', 'Adilson']);
?>