<?php 
include_once '11_for_tabela_aux.php';
?>

<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta charset="utf-8" />
</head>
<body>

<?=$tabela1?>
<hr>
<?=$tabela2?>
<hr>
<?=$lista?>
</body>
</html>
