<?php
$cont = 1;
while ($cont <= 3){
	echo "impacta<br>";
	$cont++;
}

echo "<hr>";