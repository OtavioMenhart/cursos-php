<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>

<table border="1">
	<tr>
		<td> 1.1 </td>
		<td> 1.2 </td>
		<td> 1.3 </td>
		<td> 1.4 </td>
	</tr>
	<tr>
		<td> 2.1 </td>
		<td> 2.2 </td>
		<td> 2.3 </td>
		<td> 2.4 </td>
	</tr>
	<tr>
		<td> 3.1 </td>
		<td> 3.2 </td>
		<td> 3.3 </td>
		<td> 3.4 </td>
	</tr>
	<tr>
		<td> 4.1 </td>
		<td> 4.2 </td>
		<td> 4.3 </td>
		<td> 4.4 </td>
	</tr>
</table>
</body>
</html>
