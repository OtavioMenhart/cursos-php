<!doctype html>
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php 
/*
LOCAIS NA MEM�RIA EM QUE PODEMOS ARMAZENAR INFORMA��ES
S�O IGUAIS A VARI�VEIS, MAS N�O PODEM TER O SEU CONTEUDO
ALTERADO DURANTE A EXECU��O DO C�DIGO
POR PADR�O USAR LETRAS MAIUSCULAS
N�O S�O PRECEDIDAS POR $
*/

define("NOME", "Ot�vio");
echo "NOME";
echo "<br>";
echo NOME;

?>
</body>
</html>