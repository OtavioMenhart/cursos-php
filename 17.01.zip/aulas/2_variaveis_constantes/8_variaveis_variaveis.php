<!doctype html>
<html>
<head>
<title>Estudo de vari�vel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php
$a = "animal";
echo $a;

#################################
echo "<hr>";
$$a = "cao";//$animal = "cao"

echo $animal;

?>
</body>
</html>